#include "mbed.h"

#include "IM920.hpp"
#include "2021roboSeparateBoardLib_setting.hpp"

Serial pc(USBTX,USBRX);
Serial tombed(PA_0, PA_1);

char button  = 'n';

/*
bool remotestop = false;
bool crawleron = false;
bool slow_move = false;
*/
const float move_power = 0.5;
const float half_power = 0.25;
const float PPR = 2048;

//Serial mega(PA_0, PA_1);
//rob::aXbeeCom ue(rob::xbeeCore,rob::xbee64bitAddress(0x00,0x13,0xA2,0x00,0x40,0xCA,0x9D,0x0B));
class Motor{
private:
	PwmOut motor_r, motor_l;
public:
	Motor(PinName pin_r, PinName pin_l):
	motor_r(pin_r), motor_l(pin_l){
		motor_r.period_us(1000);
		motor_l.period_us(1000);
	}
	void set_power(float power){
		if(power > 0.95){
			power = 0.95;
		}
		else if(power < -0.95){
			power = -0.95;
		}
		if(power < 0.0){
			power *= -1.0;
			motor_r = 0.0;
			motor_l = power;
		}else{
			motor_l = 0.0;
			motor_r = power;
		}
	}
	float operator=(const float power){
		set_power(power);
		//pc.printf("%f\n\r",power);
		return power;
	}
};
class regularC_ms{
private:
	unsigned long interval;
	unsigned long nextTime;
	Timer t;
public:
	regularC_ms(unsigned long intervalArg,unsigned long start=0):
	interval(intervalArg)
	{
		t.start();
		nextTime=start;
	}
	bool ist(){
		if(nextTime<(unsigned long)t.read_ms()){
			nextTime=interval+t.read_ms();
			return true;
		}else{
			return false;
		}
	}
	void set(unsigned long val){interval=val;}
	unsigned long read(){return interval;}
	operator bool(){return ist();}
};

class oneshotC_ms{
private:
	bool isActive;
	long nextTime;
	Timer t;
public:
	oneshotC_ms():isActive(false),nextTime(0){
		t.start();
	}
	long fromNowTo(const long wait){
		if(wait>=0){
			nextTime=wait+t.read_ms();
			isActive=true;
		}else{
			isActive=false;
		}
		return wait;
	}
	bool ist(){
		//pc.printf("isActive%s\n",isActive?"true":"false");
		if(isActive){
			return t.read_ms()>=nextTime;
		}
		return false;
	}
	operator bool(){return ist();}
	long operator=(const long wait){
		return fromNowTo(wait);
	}
};

class whileC_ms{
private:
	bool isActive;
	long nextTime;
	Timer t;
public:
	whileC_ms():isActive(false),nextTime(0){
		t.start();
	}
	long fromNowTo(const long wait){
		if(wait>=0){
			nextTime=wait+t.read_ms();
			isActive=true;
		}else{
			isActive=false;
		}
		return wait;
	}
	bool ist(){
		//pc.printf("isActive%s\n",isActive?"true":"false");
		if(isActive){
			return t.read_ms()<nextTime;
		}
		return false;
	}
	operator bool(){return ist();}
	long operator=(const long wait){
		return fromNowTo(wait);
	}
};

void getC()
{	

	button = tombed.getc();
	pc.printf("%c", button);
}

void getCmc()
{
	//pc.printf("%s\n",pc.getc());
    //受信割り込み処理
	/*
    const char receive = pc.getc();
	pc.printf("%c\n",receive);
	if(receive == 'c'){
		if(crawleron){
			crawleron = false;
		}else{
			crawleron = true;
		}
	}else if(receive == 'v'){
		if(slow_move){
			slow_move = false;
		}else{
			slow_move = true;
		}
	}else{	
		button = receive;
	}
	*/
}

Motor motor1(PC_8,PB_4);
Motor motor2(PC_9,PB_8);
Motor motor3(PA_10,PB_3);
Motor motor4(PB_10,PB_5);
Motor motor5(PA_11,PB_2);

regularC_ms test(50);
int main(){
	
	
	pc.baud(9600);
	pc.attach(getCmc,Serial::RxIrq);
	pc.printf("hello\n");
	wait_ms(1000);
	
	tombed.attach(getC, Serial::RxIrq);
	tombed.baud(115200);
	wait_ms(1000);

	
	// pc.printf("hello\n");
	//rob::xbeeCore.setup();
	/*
	while(1){
		if(test){
			im920.send(&val,1);
		}
	}*/
	// myled=0;
	//This is a test code
	
	while(true){
		static rob::regularC_ms printTime(100);
		
		
		
		switch(button){
			case 's':
				motor1 = -0.5;
				motor2 = 0.5;
				motor3 = 0.5;
				motor4 = -0.5;
				motor5 = 0.0;
				break;
			case 'w':
				motor1 = 0.5;
				motor2 = -0.5;
				motor3 = -0.5;
				motor4 = 0.5;
				motor5 = 0.0;
				break;
			case 'd':
				motor1 = 0.5;
				motor2 = 0.5;
				motor3 = -0.5;
				motor4 = -0.5;
				motor5 = 0.0;
				break;
			case 'a':
				motor1 = -0.5;
				motor2 = -0.5;
				motor3 = 0.5;
				motor4 = 0.5;
				motor5 = 0.0;
				break;
			case 'r':
				motor1 = -0.5;
				motor2 = 0.5;
				motor3 = -0.5;
				motor4 = 0.5;
				motor5 = 0.0;
				break;
			case 'l':
				motor1 = 0.5;
				motor2 = -0.5;
				motor3 = 0.5;
				motor4 = -0.5;
				motor5 = 0.0;
				break;
			case 'h': 
				
				
				break;
			case 'i': 
				
				break;
			case 't':
				
				break;
			case 'k':
				
				break;
			case 'n':
				motor1 = 0.0;
				motor2 = 0.0;
				motor3 = 0.0;
				motor4 = 0.0;
				motor5 = 0.0;
				break;
			default:
				motor1 = 0.0;
				motor2 = 0.0;
				motor3 = 0.0;
				motor4 = 0.0;
				motor5 = 0.0;
				break;
		}
	}

    return 0;
}